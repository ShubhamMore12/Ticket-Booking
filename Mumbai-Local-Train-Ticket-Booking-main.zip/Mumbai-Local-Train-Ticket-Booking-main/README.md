# MTicket
To run the project.

Step 1: Download and Install XAMPP

Step 2: Clone/Copy this repository and paste it in xampp/htdocs folder

Step 3: Add the train.sql file from the repository in PHPMYADMIN Database.

Video Link   : https://youtu.be/xt1Z7s5zpJM
